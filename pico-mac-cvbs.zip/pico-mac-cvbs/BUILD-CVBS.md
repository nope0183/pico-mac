# pico-mac: composite video (CVBS) output

This fork replaces the VGA output with interlaced monochrome PAL/NTSC composite video
(PIO + DMA, two GPIOs and two resistors as a DAC).

## Wiring

| Pin  | Function | Resistor |
|------|----------|----------|
| GP18 | VIDEO    | 200 ohm  |
| GP19 | SYNC     | 510 ohm  |

Join the two resistors and connect them to the centre pin of an RCA socket; ground goes
to the shield. Pins can be moved with `-DVIDEO_PIN=n` (SYNC is always VIDEO+1).

## Build

```bash
sudo apt install -y git cmake build-essential python3 xxd gcc-arm-none-eabi libnewlib-arm-none-eabi
git clone https://github.com/raspberrypi/pico-sdk.git
git -C pico-sdk submodule update --init lib/tinyusb
git clone --recursive <this repo> && cd <this repo>

# patch ROM with umac (parameters must match the firmware options below)
make -C external/umac                       # 128K, 512x342
# make -C external/umac MEMSIZE=208 DISP_WIDTH=640 DISP_HEIGHT=480
./external/umac/main -r '/path/to/4D1F8172 - MacPlus v3.ROM' -W rom.bin

mkdir -p incbin
xxd -i < rom.bin  > incbin/umac-rom.h
xxd -i < disc.bin > incbin/umac-disc.h      # or `echo > incbin/umac-disc.h` for SD only

mkdir build && cd build
PICO_SDK_PATH=../../pico-sdk cmake .. -DCVBS_STD=PAL   # or NTSC
make -j$(nproc)
```

CMake options: `CVBS_STD` (PAL|NTSC), `MEMSIZE`, `USE_VGA_RES`, `USE_SD`, `VIDEO_PIN`.
Flash `build/firmware.uf2` via BOOTSEL.

## Tuning

`src/video.c`: `VIDEO_ACTIVE_START` (vertical position), `VIDEO_H_CENTRE_PX` (horizontal position).
System clock is 240 MHz (`CVBS_SYSCLK_KHZ` in `include/hw.h`, must be a multiple of 30 MHz).
Interlaced output: single-pixel horizontal lines flicker. No colour.
